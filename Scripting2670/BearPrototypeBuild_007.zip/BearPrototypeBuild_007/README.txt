WASD to move
Space to jump
Shift to run