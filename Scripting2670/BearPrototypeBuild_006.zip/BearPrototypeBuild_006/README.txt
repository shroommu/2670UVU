README

Controls:

WASD/Arrow Keys = Move
Space = Jump
S/Down Arrow (when standing on thin platform) = fall through